<?php
session_start();

$user = false;
if (isset($_SESSION["user"]) && $_SESSION["user"] != ""){
  $user = $_SESSION["user"];
}

include_once "include/db.php";

// tikrina pasirinktą puslapį
$page = false;
$title = "Dienynas";
if (isset($_GET["page"])){
  if ($_GET["page"]== "login"){
    $page = "login";
    $title .= " - Prisijungti";
  }
  elseif ($_GET["page"]== "register"){
    $page = "register";
    $title .= " - Registracija";
  }
  elseif ($_GET["page"]== "mokiniai"){
    $page = "mokiniai";
    $title .= " - Mokinių valdymas";
  }
  elseif ($_GET["page"]== "mokytojai"){
    $page = "mokytojai";
    $title .= " - Mokytojų valdymas";
  }
  elseif ($_GET["page"]== "vartotojai"){
    $page = "vartotojai";
    $title .= " - Vartotojų valdymas";
  }

}

/*
$puslapiai = array();
$puslapiai[] = array("page"=>"home", "title"=>"");
$puslapiai[] = array("page"=>"login", "title"=>" - Prisijungti");
$puslapiai[] = array("page"=>"register", "title"=>" - Registracija");
$puslapiai[] = array("page"=>"mokiniai", "title"=>" - Mokinių valdymas");
$puslapiai[] = array("page"=>"mokytojai", "title"=>" - Mokytojų valdymas");

$page = false;
$title = "Dienynas";

if (isset($_GET["page"])){
  foreach ($puslapiai as $psl){
    if ($_GET["page"] == $psl["page"]){
      $page = $psl["page"];
      $title .= $psl["title"];
      break;
    }
  }
}
*/

/*
$puslapiai = array();
$puslapiai["home"] = array("title"=>"");
$puslapiai["login"] = array("title"=>" - Prisijungti");
$puslapiai["register"] = array("title"=>" - Registracija");
$puslapiai["mokiniai"] = array("title"=>" - Mokinių valdymas");
$puslapiai["mokytojai"] = array("title"=>" - Mokytojų valdymas");

$page = false;
$title = "Dienynas";

if (isset($_GET["page"])){
  if (isset($puslapiai[$_GET["page"]])){
    $psl = $puslapiai[$_GET["page"]];
    $page = $_GET["page"];
    $title .= $psl["title"];
  }
}
*/

/*
$puslapiai = array(
  "home" => array("title"=>""),
  "login" => array("title"=>" - Prisijungti"),
  "register" => array("title"=>" - Registracija"),
  "mokiniai" => array("title"=>" - Mokinių valdymas"),
  "mokytojai" => array("title"=>" - Mokytojų valdymas")
);

$page = false;
$title = "Dienynas";

if (isset($_GET["page"])){
  $get_page = $_GET["page"];
  if (isset($puslapiai[$get_page])){
    $page = $get_page;
    $title .= $puslapiai[$get_page]["title"];
  }
}
*/






?><!doctype html>
<html lang="en">
<?php
    include_once "include/head.php";
?>
<body>
<?php
    include "include/navigacija.php";
?>

<main role="main">
<?php
if ($page == false){
?>
  <!-- Main jumbotron for a primary marketing message or call to action -->
  <div class="jumbotron">
    <div class="container">
<?php
  if ($user != false){
    echo "<h1 class=\"display-3\">Hello, ".$user."!</h1>"; 
  } else {
    echo "<h1 class=\"display-3\">Hello, world!</h1>";
  }
?>
      <p>This is a template for a simple marketing or informational website. It includes a large callout called a jumbotron and three supporting pieces of content. Use it as a starting point to create something more unique.</p>
      <p><a class="btn btn-primary btn-lg" href="#" role="button">Learn more &raquo;</a></p>
    </div>
  </div>
<?php
}
?>
  <div class="container">
  <?php
    if ($page == false){
      include_once "include/home.php";
    } else{
      include_once "include/". $page .".php";      
    }
  ?>    
  </div> <!-- /container -->

</main>

<?php
    include_once "include/footer.php";
?>
</body>
</html>