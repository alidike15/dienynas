<?php
$message = "";
$status = 1;
$alert = "warning";

$busenos = array("Neaktyvus", "Aktyvus");
$tipai = array("Paprastas", "Administratorius");
?>
<h1 class="h3 mb-3 font-weight-normal">Vartotojų valdymas</h1>

<div class="row">
<div class="col-sm-12">
    <h2 class="h3 mb-3">Vartotojų sąrašas</h2>
    <table class="table table-striped">
    <thead class="thead-dark">
        <tr>
        <th scope="col">#</th>
        <th scope="col">El. paštas</th>

        <th scope="col">Vardas</th>
        <th scope="col">Pavardė</th>
        <th scope="col">Pareigos</th>

        <th scope="col">Būsena</th>
        <th scope="col">Tipas</th>
        <th scope="col">Valdymas</th>
        </tr>
    </thead>
    <tbody>
    <?php
    $vartotojai = array();
    try{
        // paima visus vartotojus is db
        $stmt = $db->prepare('SELECT V.id, V.email, V.status, V.type, 
            M.id as `id_mokytojo`, M.name as `name_mokytojo`, M.sname as `sname_mokytojo`,
            K.id as `id_mokinio`, K.name as `name_mokinio`, K.sname as `sname_mokinio`
            FROM `vartotojas` AS `V`
            LEFT JOIN `mokytojasv` AS `MV` ON V.id = MV.vid
            LEFT JOIN `mokinysv` AS `KV` ON V.id = KV.vid
            LEFT JOIN `mokytojas` AS `M` ON M.id = MV.mid
            LEFT JOIN `mokinys` AS `K` ON K.id = KV.mid
            ORDER BY `email`
        ');
        $stmt->execute();
        $vartotojai = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        print "DB Klaida!: " . $e->getMessage() . "<br/>";
        die();
    }
    // generuojama vartotojų lentele
    foreach ($vartotojai as $vartotojas){
        echo "<tr>";
        echo "<th scope=\"row\" class=\"text-right id\">". $vartotojas["id"] ."</th>";
        echo "<td>". $vartotojas["email"] ."</td>";

        if ($vartotojas["id_mokytojo"] != ""){
            echo "<td>". $vartotojas["name_mokytojo"] ."</td>";
            echo "<td>". $vartotojas["sname_mokytojo"] ."</td>";
            echo "<td>Mokytojas</td>";
        } elseif ($vartotojas["id_mokinio"] != ""){
            echo "<td>". $vartotojas["name_mokinio"] ."</td>";
            echo "<td>". $vartotojas["sname_mokinio"] ."</td>";
            echo "<td>Mokinys</td>";
        } else {
            echo "<td></td>";
            echo "<td></td>";
            echo "<td></td>";
        }

        
        echo "<td>". $busenos[$vartotojas["status"]] ."</td>";
        echo "<td>". $tipai[$vartotojas["type"]] ."</td>";
        echo "<td class=\"text-right\">";
            // $link = "?page=mokytojai&edit=".$mokytojas["id"];
            // echo "<a type=\"button\" class=\"btn btn-primary btn-sm\" href=\"". $link ."\" role=\"button\"><i class=\"fas fa-edit\"></i>&nbsp;Redaguoti</a>";
            // echo "&nbsp;";
            // if ($mokytojas["email"] == ""){
            //     echo "<button type=\"button\" class=\"btn btn-info btn-sm trinti\" title=\"Trinti mokytoją!!!\"><i class=\"fas fa-trash-alt\"></i></button>";
            // } else {
            //     echo "<button type=\"button\" class=\"btn btn-disabled btn-sm disabled\" title=\"Trinti mokytoją!!!\"><i class=\"fas fa-trash-alt\"></i></button>";
            // }
        echo "</td>";
        echo "</tr>";
    }    
    ?>         
    </tbody>
    </table>

</div>