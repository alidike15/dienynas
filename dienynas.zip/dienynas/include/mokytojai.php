<?php
$message = "";
$name = "";
$sname = "";
$status = 1;
$alert = "warning";

$busenos = array("Neaktyvus", "Aktyvus");

if ($page == "mokytojai"){
    // registruojamas mokytojas
    if (isset($_POST["name"]) && isset($_POST["sname"])){
        $name = trim($_POST["name"]);
        $sname = trim($_POST["sname"]);
        
        $id = false;
        $status = false;
        // redaguojamas mokytojas
        if (isset($_POST["id"]) && isset($_POST["status"])){
            $id = trim($_POST["id"]);
            $user_id = trim($_POST["user"]);
            $status = trim($_POST["status"]);
        }

        if ($name != "" && $sname != ""){
            try {
                if ($id == false){
                    // naujas mokytojas i db
                    $stmt = $db->prepare('INSERT INTO mokytojas (`name`, `sname`) VALUES (?, ?)');
                    $stmt->execute(array($name, $sname));
                    $message = "Pridėtas naujas mokytojas: ".$name." ".$sname;
                    $name = "";
                    $sname = "";
                } else {
                    // keicia mokytojo info db
                    $stmt = $db->prepare('UPDATE `mokytojas` SET `name`=?, `sname`=?, `status`=? WHERE `id`=?');
                    $stmt->execute(array($name, $sname, $status, $id));

                    if ($user_id === ""){
                        // trina mokytojo rysi su vartotoju is db
                        $stmt = $db->prepare('DELETE FROM mokytojasv WHERE `mid`=?');
                        $stmt->execute(array($id));
                    } else {
                        // prideda arba keicia mokytojo rysi su vartotoju i db
                        $stmt = $db->prepare('INSERT INTO mokytojasv (`vid`, `mid`) VALUES (?, ?) ON DUPLICATE KEY UPDATE `vid` = ?, `mid` = ?');
                        $stmt->execute(array($user_id, $id, $user_id, $id));
                    }


                    $message = "Atnaujinta mokytojo informacija: ".$name." ".$sname;
                }
                $alert = "success"; 
            } catch (PDOException $e) {
                print "DB Klaida!: " . $e->getMessage() . "<br/>";
                die();
            }
        }
        else {
            $message = "Įveskite vardą ir pavardę."; 
        }
    } elseif (isset($_POST["delete"])){
        // trina mokytoja is db
        $delete = $_POST["delete"];
        try {
            if (is_numeric($delete)){
                $stmt = $db->prepare('DELETE FROM mokytojasv WHERE `mid`=?');
                $stmt->execute(array($delete));
                $stmt = $db->prepare('DELETE FROM mokytojas WHERE `id`=?');
                $stmt->execute(array($delete));
                echo "pavyko";
                die();
            } 
        } catch (PDOException $e) {
            print "DB Klaida!: " . $e->getMessage() . "<br/>";
            die();
        }
    }
}
?>
<h1 class="h3 mb-3">Mokytojų valdymas</h1>

<div class="row">
<div class="col-sm-8">
    <h2 class="h3 mb-3">Mokytojų sąrašas</h2>
    <table class="table table-striped">
    <thead class="thead-dark">
        <tr>
        <th scope="col">#</th>
        <th scope="col">Vardas</th>
        <th scope="col">Pavardė</th>
        <th scope="col">El. Paštas</th>
        <th scope="col">Būsena</th>
        <th scope="col">Valdymas</th>
        </tr>
    </thead>
    <tbody>
    <?php
    $mokytojai = array();
    try{
        // paima visus mokytojus is db
        // $stmt = $db->prepare('SELECT * FROM `mokytojas` ORDER BY `sname`, `name`');
        $stmt = $db->prepare('SELECT M.id AS `id`, M.sname AS `sname`, M.name AS `name`, M.status AS `status`, V.email AS `email`
            FROM `mokytojas` AS `M`
            LEFT JOIN `mokytojasv` AS `MV` ON M.id = MV.mid
            LEFT JOIN `vartotojas` AS `V`  ON MV.vid = V.id
            ORDER BY `sname`, `name`
            ');
        $stmt->execute();
        $mokytojai = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        print "DB Klaida!: " . $e->getMessage() . "<br/>";
        die();
    }
    // generuojama mokytoju lentele
    foreach ($mokytojai as $mokytojas){
        echo "<tr>";
        echo "<th scope=\"row\" class=\"text-right id\">". $mokytojas["id"] ."</th>";
        echo "<td class=\"name\">". $mokytojas["name"] ."</td>";
        echo "<td class=\"sname\">". $mokytojas["sname"] ."</td>";
        echo "<td class=\"sname\">". $mokytojas["email"] ."</td>";
        echo "<td>". $busenos[$mokytojas["status"]] ."</td>";
        echo "<td class=\"text-right\">";
            $link = "?page=mokytojai&edit=".$mokytojas["id"];
            echo "<a type=\"button\" class=\"btn btn-primary btn-sm\" href=\"". $link ."\" role=\"button\"><i class=\"fas fa-edit\"></i>&nbsp;Redaguoti</a>";
            echo "&nbsp;";
            if ($mokytojas["email"] == ""){
                echo "<button type=\"button\" class=\"btn btn-info btn-sm trinti\" title=\"Trinti mokytoją!!!\"><i class=\"fas fa-trash-alt\"></i></button>";
            } else {
                echo "<button type=\"button\" class=\"btn btn-disabled btn-sm disabled\" title=\"Trinti mokytoją!!!\"><i class=\"fas fa-trash-alt\"></i></button>";
            }
        echo "</td>";
        echo "</tr>";
    }    
    ?>         
    </tbody>
    </table>
<script>
$(document).ready(function(){
   $("button.trinti").click(function(){
       var $this = $(this);
       var mokytojas = $this.parent().parent().find(".name").text() + " ";
       mokytojas += $this.parent().parent().find(".sname").text();
       var mok_id = parseInt($this.parent().parent().find(".id").text());

        var r = confirm("Ar tikrai norite ištrinti mokytoją! " + mokytojas);
        if (r == true) {
            $.ajax({
                method: "POST",
                url: "?page=mokytojai",
                data: { delete: mok_id}
            })
            .done(function( msg ) {
                // console.log(msg);
                location.href = "?page=mokytojai";
            });
        }
   });
});

</script>


</div>
<div class="col-sm-4">
<?php
    // mokytojo kūrimo forma
    $forma = "create";
    $formos_pavadinimas = "Pridėti mokytoją";
    if (isset($_GET["edit"]) && is_numeric($_GET["edit"])){
        try{
            // mokytojo redagavimo forma
            $stmt = $db->prepare('SELECT * FROM `mokytojas` WHERE `id` = ? LIMIT 1');
            $stmt->execute(array($_GET["edit"]));
            if ($mokytojas = $stmt->fetch(PDO::FETCH_ASSOC)){
                $forma = "update";
                $formos_pavadinimas = "Redaguoti mokytoją";
                $name = $mokytojas["name"];
                $sname = $mokytojas["sname"];
                $status = $mokytojas["status"];
            }
        } catch (PDOException $e) {
            print "DB Klaida!: " . $e->getMessage() . "<br/>";
            die();
        }
        if (isset($_GET["user"]) && $_GET["user"] !== ""){

        }
    }
?>
<form class="" method="post" action="?page=mokytojai">
    <?php require "include/message.php";?>
    <h2 class="h3 mb-3"><?php echo $formos_pavadinimas; ?></h2>
    <div class="form-group">
        <label class="" for="inputName">Vardas</label>
        <input type="text" id="inputName" name="name" value="<?php echo $name;?>" class="form-control" placeholder="Vardas" required>
    </div>
    <div class="form-group">
        <label class="" for="inputSname">Pavardė</label>
        <input type="text" id="inputSname" name="sname" value="<?php echo $sname;?>" class="form-control" placeholder="Pavardė" required>
    </div>
    <?php
    if ($forma == "update"){
        // papildomi formos laukai kai forma skirta redagavimui
        echo '<input type="hidden" name="id" value="'. $mokytojas["id"] .'">';

        echo '<div class="form-group">';
        echo '<label class="" for="inputStatus">Būsena</label>';
        echo '<select id="inputStatus" name="status" value="'. $status .'" class="form-control" required>';
            foreach ($busenos as $k => $v){
                $sel = "";
                if ($k == $status) $sel = "selected";
                echo '<option value="'. $k .'" '. $sel .'>'. $v .'</option>';
                // echo '<option value="'. $k .'" '. ($k == $status?"selected":"") .'>'. $v .'</option>';
            }
        echo '</select>';
        echo '</div>';

        echo '<div class="form-group">';
        echo '<label class="" for="inputUser">Vartotojas</label>';
        
        // vartotojų select elemento generavimas
        $visi_vartotojai = array();
        try{
            $stmt = $db->prepare('SELECT V.id, V.email, M.mid 
                FROM `vartotojas` AS `V` 
                LEFT JOIN `mokytojasv` AS `M` ON V.id = M.vid 
                LEFT JOIN `mokinysv` AS `K` ON V.id = K.vid 
                WHERE M.vid IS NULL AND K.vid IS NULL 
                    AND V.status <> 0 OR M.mid = ? 
                ORDER BY V.email');

            $stmt->execute(array($mokytojas["id"]));
            $visi_vartotojai = $stmt->fetchAll(PDO::FETCH_ASSOC);
            // echo "<pre>";
            //     print_r($visi_vartotojai);
            // echo "</pre>";
        } catch (PDOException $e) {
            print "DB Klaida!: " . $e->getMessage() . "<br/>";
            die();
        }     

        echo '<select id="inputUser" name="user" value="" class="form-control">';
            echo '<option value=""> - Nepriskirtas </option>';
            foreach ($visi_vartotojai as $k => $v){
                $sel = "";
                if ($v["mid"] == $mokytojas["id"]) $sel = "selected";
                echo '<option value="'. $v["id"] .'" '. $sel .'>'. $v['email'] .'</option>';
            }
        echo '</select>';
        echo '</div>';

        echo '<div class="text-center">';
        echo '<a href="?page=mokytojai" class=" col-sm-5 mr-2 btn btn-lg btn-secondary">Atšaukti</a>';
        echo '<button class=" col-sm-5 btn btn-lg btn-primary " type="submit">Saugoti</button>';
        echo '</div>';    
    } else {
        echo '<button class="btn btn-lg btn-primary btn-block" type="submit">Siųsti</button>';
    }
    ?>
    
</form>
</div>
</div>