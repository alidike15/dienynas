<?php
$message = "";
$email = "";
$alert = "warning";
if ($page == "login"){
    if (isset($_POST["email"]) && isset($_POST["pass"])){
        $email = $_POST["email"];
        $pass = $_POST["pass"];
        
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)){
            $message = "Neteisingas El. paštas";            
        } elseif ($pass == ""){
            $message = "Neįvestas slaptažodis";
        } else {
            try {
                $stmt = $db->prepare('SELECT * FROM vartotojas WHERE `email` = ?');
                $stmt->execute(array($email));
                $vartotojas = $stmt->fetch();
                // echo "<pre>";
                // print_r($vartotojas);
                // echo "</pre>";
                
                if ($vartotojas == false){
                    $message = "Tokio vartotojo nėra";
                } else {
                    
                    $pass = hash("sha1", $pass.$druska);
                    if ($pass == $vartotojas["pass"]){
                        $message = "Prisijungimo duomenys teisingi";
                        $alert = "success";
                        $_SESSION["user"] = $email;
                        header("Location: ?page=home");
                        die();
                    } else {
                        $message = "Slaptažodis nesutampa";
                    }
                }
            } catch (PDOException $e) {
                print "DB Klaida!: " . $e->getMessage() . "<br/>";
                die();
            }
        }
        
        
    }
}
?>

<div class="row justify-content-center">
<div class="col-sm-4">
<form class="form-signin" method="post" action="?page=login">
    <?php require "include/message.php";?>
    <h1 class="h3 mb-3 font-weight-normal">Prisijungti</h1>
    <div class="form-group">
        <label class="" for="inputEmail">El. pašto adresas</label>
        <input type="email" id="inputEmail" name="email" value="<?php echo $email;?>" class="form-control" placeholder="El. pašto adresas" required autofocus>
    </div>
    <div class="form-group">
        <label for="inputPassword" class="">Slaptažodis</label>
        <input type="password" id="inputPassword" name="pass" class="form-control" placeholder="Slaptažodis" required>
    </div>
    <button class="btn btn-lg btn-primary btn-block" type="submit">Siųsti</button>
</form>
</div>
</div>