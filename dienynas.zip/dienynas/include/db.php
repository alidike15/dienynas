<?php
$db_host = "localhost";
$db_user = "root";
$db_pass = "";
$db_name = "dienynas2";

$druska = "64359b7192746a14740ad4bb7afe4e097327d0790190fd16";

try {
    $db = new PDO('mysql:host='.$db_host.';dbname='.$db_name, $db_user, $db_pass);
    // print "Pavyko! prisijungėme prie db";

} catch (PDOException $e) {
    print "DB Klaida!: " . $e->getMessage() . "<br/>";
    die();
}