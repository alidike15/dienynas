<?php
if ($message != ""){
    $pranesimas = "<div class=\"alert alert-". $alert ." alert-dismissible fade show\" role=\"alert\">";
    $pranesimas .= $message;
    $pranesimas .= "<button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-label=\"Close\">";
    $pranesimas .= "<span aria-hidden=\"true\">&times;</span>";
    $pranesimas .= "</button>";
    $pranesimas .= "</div>";
    echo $pranesimas;
}
?>