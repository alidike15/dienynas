
<footer class="container">
  <p>&copy; 2020</p>
</footer>

