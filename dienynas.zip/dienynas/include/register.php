<?php
$message = "";
$alert = "warning";
if ($page == "register"){
    if (isset($_POST["email"]) && isset($_POST["pass"]) && isset($_POST["pass2"])){
        $email = $_POST["email"];
        $pass = $_POST["pass"];
        $pass2 = $_POST["pass2"];

        
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)){
            $message = "Neteisingas El. paštas";            
        } elseif ($pass != $pass2){
            $message = "Nesutampa slaptažodžiai";
        } elseif ($pass == ""){
            $message = "Neįvestas slaptažodis";
        } else {
            try {
                $stmt = $db->prepare('SELECT * FROM vartotojas WHERE `email` = ?');
                $stmt->execute(array($email));
                $vartotojas = $stmt->fetchAll();
                if (count($vartotojas) > 0){
                    $message = "Įvestas el. paštas jau naudojamas";
                } else {
                    $stmt = $db->prepare('INSERT INTO vartotojas (`email`, `pass`) VALUES (?, ?)');
                    $pass = hash("sha1", $pass.$druska);
                    $stmt->execute(array($email, $pass));
                    $message = "Vartotojas užregistruotas";
                }
            } catch (PDOException $e) {
                print "DB Klaida!: " . $e->getMessage() . "<br/>";
                die();
            }
        }
        
        
    }
}
?>

<div class="row justify-content-center">
<div class="col-sm-4">
<form class="form-register" method="post" action="?page=register">
    <?php require "include/message.php";?>
    <h1 class="h3 mb-3 font-weight-normal">Registracija</h1>
    <div class="form-group">
        <label class="" for="inputEmail">El. pašto adresas</label>
        <input type="email" id="inputEmail" name="email" class="form-control" placeholder="El. pašto adresas" required autofocus>
    </div>
    <div class="form-group">
        <label for="inputPassword" class="">Slaptažodis</label>
        <input type="password" id="inputPassword" name="pass" class="form-control" placeholder="Slaptažodis" required>
    </div>
    <div class="form-group">
        <label for="inputPassword2" class="">Pakartoti slaptažodį</label>
        <input type="password" id="inputPassword2" name="pass2" class="form-control" placeholder="Pakartoti slaptažodį" required>
    </div>
    <button class="btn btn-lg btn-primary btn-block" type="submit">Siųsti</button>
</form>
<script>
    $("document").ready(function(){

        $("form.form-register").submit(function(e){

            var pass1 = $(this).find("#inputPassword").val();
            var pass2 = $(this).find("#inputPassword2").val();
            if (pass1 != pass2){
                e.preventDefault();
                console.log("Slaptažodžiai nesutampa");
                var pranesimas = "<div class=\"alert alert-warning alert-dismissible fade show\" role=\"alert\">";
                pranesimas += "Slaptažodžiai nesutampa!";
                pranesimas += "<button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-label=\"Close\">";
                pranesimas += "<span aria-hidden=\"true\">&times;</span>";
                pranesimas += "</button>";
                pranesimas += "</div>";
                $(this).prepend(pranesimas);
            }
        });
    });
</script>
</div>
</div>